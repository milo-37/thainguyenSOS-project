<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use App\Models\Kho;
use App\Models\VatTu;
use App\Models\PhieuNx;
use App\Models\PhieuNxCt;

class KhoController extends Controller
{
    // GET /api/admin/kho
    public function index(Request $req)
    {
        $q = Kho::query()->orderBy('ten');
        if ($kw = $req->query('q')) {
            $q->where('ten','like',"%$kw%");
        }
        return response()->json(['data' => $q->get()]);
    }

    // GET /api/admin/kho/{id}/ton
    public function ton($id)
    {
        // Tồn = Tổng nhập + chuyển vào - tổng xuất - chuyển ra
        $rows = DB::table('vattu as vt')
            ->leftJoin('phieu_nx_ct as d','d.vat_tu_id','=','vt.id')
            ->leftJoin('phieu_nx as p','p.id','=','d.phieu_id')
            ->selectRaw("
                vt.id, vt.ten, vt.donvi,
                COALESCE(SUM(
                    CASE
                        WHEN p.loai='nhap'       AND p.kho_to_id=? THEN d.so_luong
                        WHEN p.loai='chuyen'     AND p.kho_to_id=? THEN d.so_luong
                        WHEN p.loai IS NULL THEN 0
                        ELSE 0
                    END
                ),0)
                -
                COALESCE(SUM(
                    CASE
                        WHEN p.loai='xuat'       AND p.kho_from_id=? THEN d.so_luong
                        WHEN p.loai='chuyen'     AND p.kho_from_id=? THEN d.so_luong
                        ELSE 0
                    END
                ),0) as so_luong
            ", [$id,$id,$id,$id])
            ->groupBy('vt.id','vt.ten','vt.donvi')
            ->orderBy('vt.ten')
            ->get();

        return response()->json(['data' => $rows]);
    }

    // GET /api/admin/kho/{id}/lich-su
    public function lichSu($id)
    {
        $rows = DB::table('phieu_nx as p')
            ->leftJoin('phieu_nx_ct as d','d.phieu_id','=','p.id')
            ->leftJoin('vattu as vt','vt.id','=','d.vat_tu_id')
            ->select('p.*', DB::raw('JSON_ARRAYAGG(JSON_OBJECT(
                "vat_tu_id", d.vat_tu_id,
                "ten", vt.ten,
                "so_luong", d.so_luong,
                "don_vi", COALESCE(d.don_vi, vt.donvi)
            )) as chi_tiet'))
            ->where(function($q) use ($id){
                $q->where('p.kho_from_id', $id)->orWhere('p.kho_to_id', $id);
            })
            ->groupBy('p.id')
            ->orderByDesc('p.created_at')
            ->limit(50)
            ->get()
            ->map(function($r){
                $r->chi_tiet = json_decode($r->chi_tiet ?? '[]', true);
                return $r;
            });

        return response()->json(['data' => $rows]);
    }

    // POST /api/admin/kho/nhap
    public function nhap(Request $req)
    {
        $data = $req->validate([
            'kho_to_id' => ['required','integer','exists:kho,id'],
            'ghi_chu'   => ['nullable','string'],
            'items'     => ['required','array','min:1'],
            'items.*.vat_tu_id' => ['required','integer','exists:vattu,id'],
            'items.*.so_luong'  => ['required','numeric','min:0.0001'],
            'items.*.don_vi'    => ['nullable','string'],
        ]);

        $userId = $req->user()?->id;

        DB::transaction(function() use ($data, $userId) {
            $p = PhieuNx::create([
                'loai' => 'nhap',
                'kho_to_id' => $data['kho_to_id'],
                'nguoi_tao_id' => $userId,
                'ghi_chu' => $data['ghi_chu'] ?? null,
            ]);

            foreach ($data['items'] as $it) {
                $donvi = $it['don_vi'] ?? VatTu::find($it['vat_tu_id'])->donvi;
                PhieuNxCt::create([
                    'phieu_id' => $p->id,
                    'vat_tu_id'=> $it['vat_tu_id'],
                    'so_luong' => $it['so_luong'],
                    'don_vi'   => $donvi,
                ]);
            }
        });

        return response()->json(['success'=>true]);
    }

    // POST /api/admin/kho/xuat
    public function xuat(Request $req)
    {
        $data = $req->validate([
            'kho_from_id' => ['required','integer','exists:kho,id'],
            'ghi_chu'     => ['nullable','string'],
            'items'       => ['required','array','min:1'],
            'items.*.vat_tu_id' => ['required','integer','exists:vattu,id'],
            'items.*.so_luong'  => ['required','numeric','min:0.0001'],
            'items.*.don_vi'    => ['nullable','string'],
        ]);

        // kiểm tồn không cho âm
        $currentTon = $this->getTonMap($data['kho_from_id']);

        foreach ($data['items'] as $it) {
            $ton = $currentTon[$it['vat_tu_id']] ?? 0;
            if ($ton < $it['so_luong']) {
                return response()->json([
                    'message' => "Vật tư ID {$it['vat_tu_id']} không đủ tồn (còn $ton)"
                ], 422);
            }
        }

        $userId = $req->user()?->id;

        DB::transaction(function() use ($data, $userId) {
            $p = PhieuNx::create([
                'loai' => 'xuat',
                'kho_from_id' => $data['kho_from_id'],
                'nguoi_tao_id' => $userId,
                'ghi_chu' => $data['ghi_chu'] ?? null,
            ]);

            foreach ($data['items'] as $it) {
                $donvi = $it['don_vi'] ?? VatTu::find($it['vat_tu_id'])->donvi;
                PhieuNxCt::create([
                    'phieu_id' => $p->id,
                    'vat_tu_id'=> $it['vat_tu_id'],
                    'so_luong' => $it['so_luong'],
                    'don_vi'   => $donvi,
                ]);
            }
        });

        return response()->json(['success'=>true]);
    }

    // POST /api/admin/kho/chuyen
    public function chuyen(Request $req)
    {
        $data = $req->validate([
            'kho_from_id' => ['required','integer','exists:kho,id'],
            'kho_to_id'   => ['required','integer','different:kho_from_id','exists:kho,id'],
            'ghi_chu'     => ['nullable','string'],
            'items'       => ['required','array','min:1'],
            'items.*.vat_tu_id' => ['required','integer','exists:vattu,id'],
            'items.*.so_luong'  => ['required','numeric','min:0.0001'],
            'items.*.don_vi'    => ['nullable','string'],
        ]);

        $currentTon = $this->getTonMap($data['kho_from_id']);
        foreach ($data['items'] as $it) {
            $ton = $currentTon[$it['vat_tu_id']] ?? 0;
            if ($ton < $it['so_luong']) {
                return response()->json([
                    'message' => "Vật tư ID {$it['vat_tu_id']} không đủ tồn (còn $ton)"
                ], 422);
            }
        }

        $userId = $req->user()?->id;

        DB::transaction(function() use ($data, $userId) {
            $p = PhieuNx::create([
                'loai' => 'chuyen',
                'kho_from_id' => $data['kho_from_id'],
                'kho_to_id'   => $data['kho_to_id'],
                'nguoi_tao_id'=> $userId,
                'ghi_chu'     => $data['ghi_chu'] ?? null,
            ]);

            foreach ($data['items'] as $it) {
                $donvi = $it['don_vi'] ?? VatTu::find($it['vat_tu_id'])->donvi;
                PhieuNxCt::create([
                    'phieu_id' => $p->id,
                    'vat_tu_id'=> $it['vat_tu_id'],
                    'so_luong' => $it['so_luong'],
                    'don_vi'   => $donvi,
                ]);
            }
        });

        return response()->json(['success'=>true]);
    }

    // util: map vattu_id => ton (use by xuất/chuyển)
    private function getTonMap($khoId): array
    {
        $rows = DB::table('vattu as vt')
            ->leftJoin('phieu_nx_ct as d','d.vat_tu_id','=','vt.id')
            ->leftJoin('phieu_nx as p','p.id','=','d.phieu_id')
            ->selectRaw("
                vt.id,
                COALESCE(SUM(
                    CASE
                        WHEN p.loai='nhap'   AND p.kho_to_id=? THEN d.so_luong
                        WHEN p.loai='chuyen' AND p.kho_to_id=? THEN d.so_luong
                        ELSE 0 END
                ),0)
                -
                COALESCE(SUM(
                    CASE
                        WHEN p.loai='xuat'   AND p.kho_from_id=? THEN d.so_luong
                        WHEN p.loai='chuyen' AND p.kho_from_id=? THEN d.so_luong
                        ELSE 0 END
                ),0) as so_luong
            ", [$khoId,$khoId,$khoId,$khoId])
            ->groupBy('vt.id')
            ->get();

        $map = [];
        foreach ($rows as $r) $map[$r->id] = (float)$r->so_luong;
        return $map;
    }

    public function store(Request $req)
    {
        die("1");
        $data = $req->validate([
            'ten'     => ['required','string','max:255','unique:kho,ten'],
            'mo_ta'   => ['nullable','string'],
            'cum_id'  => ['nullable','integer','exists:cum,id'], // đổi lại tên bảng cum nếu khác
            'dia_chi' => ['nullable','string','max:255'],
            'ghichu'  => ['nullable','string'],
        ]);

        $kho = Kho::create($data);

        return response()->json(['data'=>$kho], 201);
    }

// PUT /api/admin/kho/{id}
    public function update(Request $req, $id)
    {
        $kho = Kho::findOrFail($id);

        $data = $req->validate([
            'ten'     => ['required','string','max:255', Rule::unique('kho','ten')->ignore($kho->id)],
            'mo_ta'   => ['nullable','string'],
            'cum_id'  => ['nullable','integer','exists:cum,id'],
            'dia_chi' => ['nullable','string','max:255'],
            'ghichu'  => ['nullable','string'],
        ]);

        $kho->fill($data)->save();

        return response()->json(['data'=>$kho]);
    }

// DELETE /api/admin/kho/{id}
    public function destroy($id)
    {
        $kho = Kho::findOrFail($id);

        // Không cho xóa nếu đã có chứng từ liên quan
        $refCount = PhieuNx::where('kho_from_id',$kho->id)->orWhere('kho_to_id',$kho->id)->count();
        if ($refCount > 0) {
            return response()->json([
                'message' => 'Kho đã phát sinh chứng từ nên không thể xóa.'
            ], 422);
        }

        $kho->delete();

        return response()->json(['success'=>true]);
    }
}
