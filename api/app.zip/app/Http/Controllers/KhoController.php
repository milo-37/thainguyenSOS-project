<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KhoController extends Controller
{
    // Danh mục vật tư
    public function dsVatTu() {
        return DB::table('vattu')->orderBy('ten')->get();
    }
    public function taoVatTu(Request $r) {
        $d = $r->validate(['ten'=>'required','donvi'=>'nullable','ma'=>'nullable','ghichu'=>'nullable']);
        $id = DB::table('vattu')->insertGetId([...$d,'created_at'=>now(),'updated_at'=>now()]);
        return ['id'=>$id];
    }

    // Kho
    public function dsKho() {
        return DB::table('kho')
            ->leftJoin('kho_ton','kho.id','=','kho_ton.kho_id')
            ->selectRaw('kho.id,kho.ten,kho.dia_chi,COALESCE(SUM(kho_ton.so_luong),0) tong')
            ->groupBy('kho.id','kho.ten','kho.dia_chi')
            ->orderBy('kho.id')->get();
    }
    public function taoKho(Request $r) {
        $d=$r->validate(['ten'=>'required','dia_chi'=>'nullable','ghichu'=>'nullable']);
        $id=DB::table('kho')->insertGetId([...$d,'created_at'=>now(),'updated_at'=>now()]);
        return ['id'=>$id];
    }
    public function tonKho($khoId) {
        return DB::table('kho_ton')
            ->join('vattu','vattu.id','=','kho_ton.vattu_id')
            ->where('kho_ton.kho_id',$khoId)
            ->select('vattu_id','vattu.ten','vattu.donvi','so_luong')
            ->orderBy('vattu.ten')->get();
    }

    // Nhập/Xuất 1 kho
    public function giaoDich(Request $r) {
        $data = $r->validate([
            'loai'=>'required|in:nhap,xuat',
            'kho_id'=>'required|integer',
            'ghichu'=>'nullable|string',
            'dong'=>'required|array|min:1',
            'dong.*.vattu_id'=>'required|integer',
            'dong.*.so_luong'=>'required|numeric|min:0.0001',
        ]);

        return DB::transaction(function () use ($data) {
            $txn = DB::table('kho_giaodich')->insertGetId([
                'loai'=>$data['loai'],'kho_id'=>$data['kho_id'],'tao_boi'=>auth()->id(),'ghichu'=>$data['ghichu']??null
            ]);

            foreach ($data['dong'] as $d) {
                DB::table('kho_dong')->insert(['giaodich_id'=>$txn,'vattu_id'=>$d['vattu_id'],'so_luong'=>$d['so_luong']]);
                $delta = $data['loai']==='nhap' ? $d['so_luong'] : -$d['so_luong'];

                $row = DB::table('kho_ton')->where(['kho_id'=>$data['kho_id'],'vattu_id'=>$d['vattu_id']])->first();
                if ($row) {
                    DB::table('kho_ton')->where(['kho_id'=>$data['kho_id'],'vattu_id'=>$d['vattu_id']])
                        ->update(['so_luong'=>DB::raw('so_luong + '.$delta)]);
                } else {
                    DB::table('kho_ton')->insert(['kho_id'=>$data['kho_id'],'vattu_id'=>$d['vattu_id'],'so_luong'=>$delta]);
                }
                if ($data['loai']==='xuat') {
                    $check = DB::table('kho_ton')->where(['kho_id'=>$data['kho_id'],'vattu_id'=>$d['vattu_id']])->value('so_luong');
                    if ($check < 0) throw new \Exception('Tồn kho âm (vật tư '.$d['vattu_id'].')');
                }
            }
            return ['giaodich_id'=>$txn];
        });
    }

    // Chuyển kho
    public function chuyenKho(Request $r) {
        $data = $r->validate([
            'kho_tu_id'=>'required|integer|different:kho_den_id',
            'kho_den_id'=>'required|integer',
            'ghichu'=>'nullable|string',
            'dong'=>'required|array|min:1',
            'dong.*.vattu_id'=>'required|integer',
            'dong.*.so_luong'=>'required|numeric|min:0.0001',
        ]);

        return DB::transaction(function () use ($data) {
            $txn = DB::table('kho_giaodich')->insertGetId([
                'loai'=>'chuyen','kho_id'=>$data['kho_tu_id'],'kho_den_id'=>$data['kho_den_id'],
                'tao_boi'=>auth()->id(),'ghichu'=>$data['ghichu']??null
            ]);

            foreach ($data['dong'] as $d) {
                DB::table('kho_dong')->insert(['giaodich_id'=>$txn,'vattu_id'=>$d['vattu_id'],'so_luong'=>$d['so_luong']]);

                // trừ kho nguồn
                $src = DB::table('kho_ton')->where(['kho_id'=>$data['kho_tu_id'],'vattu_id'=>$d['vattu_id']])->first();
                if (!$src || $src->so_luong < $d['so_luong']) throw new \Exception('Kho nguồn không đủ hàng');
                DB::table('kho_ton')->where(['kho_id'=>$data['kho_tu_id'],'vattu_id'=>$d['vattu_id']])
                    ->update(['so_luong'=>DB::raw('so_luong - '.$d['so_luong'])]);

                // cộng kho đích
                $dst = DB::table('kho_ton')->where(['kho_id'=>$data['kho_den_id'],'vattu_id'=>$d['vattu_id']])->first();
                if ($dst) {
                    DB::table('kho_ton')->where(['kho_id'=>$data['kho_den_id'],'vattu_id'=>$d['vattu_id']])
                        ->update(['so_luong'=>DB::raw('so_luong + '.$d['so_luong'])]);
                } else {
                    DB::table('kho_ton')->insert(['kho_id'=>$data['kho_den_id'],'vattu_id'=>$d['vattu_id'],'so_luong'=>$d['so_luong']]);
                }
            }
            return ['giaodich_id'=>$txn];
        });
    }
    public function tons(Request $req) {
        return response()->json($q->paginate($req->get('per_page',50)));
    }


    public function history(Request $req) {
        $q = \App\Models\PhieuNX::query()->with(['chiTiet.vatTu','khoFrom','khoTo','nguoiTao'])->orderByDesc('id');
        if ($khoId = $req->get('kho_id')) $q->where(function($s) use ($khoId){ $s->where('kho_from_id',$khoId)->orWhere('kho_to_id',$khoId); });
        return response()->json($q->paginate($req->get('per_page',50)));
    }


    public function nhap(Request $req){
        $data = $req->validate([
            'kho_to_id'=>'required|exists:kho,id',
            'items'=>'required|array',
            'items.*.vattu_id'=>'required|exists:vat_tu,id',
            'items.*.so_luong'=>'required|numeric|min:0.01',
            'items.*.don_vi'=>'nullable|string',
            'ghi_chu'=>'nullable|string',
        ]);
        return $this->savePhieu('nhap',null,$data['kho_to_id'],$data['items'],$req->user()->id,$data['ghi_chu']??null);
    }


    public function xuat(Request $req){
        $data = $req->validate([
            'kho_from_id'=>'required|exists:kho,id',
            'items'=>'required|array',
            'items.*.vattu_id'=>'required|exists:vat_tu,id',
            'items.*.so_luong'=>'required|numeric|min:0.01',
            'items.*.don_vi'=>'nullable|string',
            'ghi_chu'=>'nullable|string',
        ]);
        return $this->savePhieu('xuat',$data['kho_from_id'],null,$data['items'],$req->user()->id,$data['ghi_chu']??null);
    }


    public function chuyen(Request $req){
        $data = $req->validate([
            'kho_from_id'=>'required|exists:kho,id',
            'kho_to_id'=>'required|exists:kho,id|different:kho_from_id',
            'items'=>'required|array',
            'items.*.vattu_id'=>'required|exists:vat_tu,id',
            'items.*.so_luong'=>'required|numeric|min:0.01',
            'items.*.don_vi'=>'nullable|string',
            'ghi_chu'=>'nullable|string',
        ]);
        return $this->savePhieu('chuyen',$data['kho_from_id'],$data['kho_to_id'],$data['items'],$req->user()->id,$data['ghi_chu']??null);
    }


    private function savePhieu($loai,$from,$to,$items,$nguoiTao,$ghiChu){
        return \DB::transaction(function() use ($loai,$from,$to,$items,$nguoiTao,$ghiChu){
            $phieu = \App\Models\PhieuNX::create([
                'loai'=>$loai,
                'kho_from_id'=>$from,
                'kho_to_id'=>$to,
                'nguoi_tao_id'=>$nguoiTao,
                'ghi_chu'=>$ghiChu,
            ]);
            foreach($items as $it){
                \App\Models\PhieuNXCT::create([
                    'phieu_id'=>$phieu->id,
                    'vattu_id'=>$it['vattu_id'],
                    'so_luong'=>$it['so_luong'],
                    'don_vi'=>$it['don_vi'] ?? null,
                ]);
// cập nhật tồn
                if (in_array($loai,['xuat','chuyen'])){
                    $this->capNhatTon($from,$it['vattu_id'],-$it['so_luong']);
                }
                if (in_array($loai,['nhap','chuyen'])){
                    $this->capNhatTon($to,$it['vattu_id'],$it['so_luong']);
                }
            }
            return response()->json($phieu->load(['chiTiet.vatTu','khoFrom','khoTo','nguoiTao']));
        });
    }


    private function capNhatTon($khoId,$vatTuId,$delta){
        $ton = \App\Models\KhoTon::firstOrCreate(['kho_id'=>$khoId,'vattu_id'=>$vatTuId]);
        $moi = ($ton->so_luong ?? 0) + $delta;
        if ($moi < 0) abort(422,'Tồn kho không đủ');
        $ton->so_luong = $moi; $ton->save();
    }
}
