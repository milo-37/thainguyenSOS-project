<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;


class KhoTon extends Model
{
    protected $table = 'kho_ton';
    protected $fillable = ['kho_id','vat_tu_id','so_luong'];
    public function kho(){ return $this->belongsTo(Kho::class,'kho_id'); }
    public function vatTu(){ return $this->belongsTo(VatTu::class,'vat_tu_id'); }
}
