<?php
namespace App\Http\Controllers;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Models\YeuCau;
use App\Models\VatTu;
use App\Models\TepDinhKem;
use App\Models\YeuCauVatTu;

class YeuCauController extends Controller
{
    public function index(Request $req)
    {
        $q = YeuCau::query()
            ->select([
                'id','loai','noidung','ten_nguoigui','sdt_nguoigui',
                'lat','lng','so_nguoi','trang_thai','created_at'
            ])
            ->with([
                'media:id,yeucau_id,type,url,thumb',
                'vattuChiTiet' => function ($q) {
                    $q->select(['id','yeucau_id','vattu_id','so_luong','don_vi'])
                        ->with('vattu:id,ten,don_vi');
                }
            ]);

        // lọc loại
        if ($req->filled('loai')) {
            $q->where('loai', $req->string('loai'));
        }

        // từ khóa: nội dung, tên, sđt
        if ($req->filled('q')) {
            $kw = trim($req->string('q'));
            $q->where(function($s) use ($kw) {
                $s->where('noidung','like',"%{$kw}%")
                    ->orWhere('ten_nguoigui','like',"%{$kw}%")
                    ->orWhere('sdt_nguoigui','like',"%{$kw}%");
            });
        }

        // trong N giờ gần nhất
        if ($req->filled('hours')) {
            $hours = (int)$req->input('hours');
            if ($hours > 0) {
                $q->where('created_at', '>=', now()->subHours($hours));
            }
        }

        // lọc theo bán kính (km) dựa trên lat/lng trung tâm
        if ($req->filled('center_lat') && $req->filled('center_lng') && $req->filled('radius_km')) {
            $lat = (float) $req->input('center_lat');
            $lng = (float) $req->input('center_lng');
            $radius = (float) $req->input('radius_km');

            // Haversine (km) – MySQL/MariaDB
            $haversine = "(6371 * acos( cos(radians(?)) * cos(radians(lat)) * cos(radians(lng) - radians(?)) + sin(radians(?)) * sin(radians(lat)) ) )";

            $q->selectRaw("$haversine AS distance", [$lat,$lng,$lat])
                ->having('distance', '<=', $radius)
                ->orderBy('distance');
        } else {
            $q->latest('id');
        }

        // phân trang nhẹ (tuỳ bạn)
        // $data = $q->paginate(200);

        $data = $q->get();

        // Trả đúng cấu trúc FE đang đọc
        return response()->json([
            'data' => $data->map(function(YeuCau $r){
                return [
                    'id'            => $r->id,
                    'loai'          => $r->loai,
                    'noidung'       => $r->noidung,
                    'ten_nguoigui'  => $r->ten_nguoigui,
                    'sdt_nguoigui'  => $r->sdt_nguoigui,
                    'lat'           => (float)$r->lat,
                    'lng'           => (float)$r->lng,
                    'so_nguoi'      => $r->so_nguoi,
                    'trang_thai'    => $r->trang_thai,
                    'created_at'    => $r->created_at,
                    // media: [{url,type,thumb}]
                    'media' => $r->media->map(fn($m)=>[
                        'url'=>$m->url, 'type'=>$m->type, 'thumb'=>$m->thumb,
                    ])->values(),
                    // vattu_chitiet: [{ten,so_luong,don_vi}]
                    'vattu_chitiet' => $r->vattuChiTiet->map(function($c){
                        return [
                            'ten'      => $c->vattu->ten ?? '',
                            'so_luong' => $c->so_luong,
                            'don_vi'   => $c->don_vi ?: ($c->vattu->don_vi ?? ''),
                        ];
                    })->values(),
                ];
            }),
        ]);
    }
    public function indexAdmin(Request $req)
    {
        $q = YeuCau::query()->orderByDesc('id');

        if ($kw = $req->get('q')) {
            $q->where(function ($s) use ($kw) {
                $s->where('ten','like',"%$kw%")
                    ->orWhere('so_dien_thoai','like',"%$kw%")
                    ->orWhere('noi_dung','like',"%$kw%")
                    ->orWhere('dia_chi_text','like',"%$kw%");
            });
        }
        if ($loai = $req->get('loai')) $q->where('loai',$loai);
        if ($tt = $req->get('trang_thai')) {
            $arr = array_filter(array_map('trim', explode(',', $tt)));
            if ($arr) $q->whereIn('trang_thai', $arr);
        }
        if ($cumId = $req->get('cum_id')) {
            $q->whereHas('phanCongs', fn($s)=>$s->where('cum_id',$cumId));
        }
        if ((int)$req->get('assigned_to_me') === 1 && $req->user()) {
            $uid = $req->user()->id;
            $q->whereHas('phanCongs', fn($s)=>$s->where('user_id',$uid));
        }

        // Quan hệ chắc chắn có
        $q->with(['phanCongs.cum','phanCongs.user']);

        $page = $q->paginate($req->integer('per_page',20));
        $ids  = collect($page->items())->pluck('id')->all();

        // Media theo bảng tep_dinhkem (không đụng yeucau_id)
        $media = \App\Models\TepDinhKem::query()
            ->where('doi_tuong','yeu_cau')
            ->whereIn('doi_tuong_id',$ids)
            ->get()
            ->groupBy('doi_tuong_id');

        $data = collect($page->items())->map(function($it) use ($media){
            $row = $it->toArray();
            $row['media'] = ($media[$it->id] ?? collect())->map(fn($m)=>[
                'id'=>(int)$m->id,
                'type'=> str_starts_with((string)$m->mime,'video')?'video':'image',
                'url'=>$m->duong_dan,
            ])->values();
            return $row;
        });

        return response()->json([
            'current_page'=>$page->currentPage(),
            'per_page'=>$page->perPage(),
            'total'=>$page->total(),
            'last_page'=>$page->lastPage(),
            'data'=>$data,
        ]);
    }

    /** GET /api/yeucau/{id} – trả chi tiết 1 bản ghi (kèm media & vật tư) */
    public function show($id)
    {
        $r = YeuCau::query()
            ->with([
                'media:id,yeucau_id,type,url,thumb',
                'vattuChiTiet' => function ($q) {
                    $q->select(['id','yeucau_id','vattu_id','so_luong','don_vi'])
                        ->with('vattu:id,ten,don_vi');
                }
            ])
            ->findOrFail($id);

        return response()->json([
            'id'            => $r->id,
            'loai'          => $r->loai,
            'noidung'       => $r->noidung,
            'ten_nguoigui'  => $r->ten_nguoigui,
            'sdt_nguoigui'  => $r->sdt_nguoigui,
            'lat'           => (float)$r->lat,
            'lng'           => (float)$r->lng,
            'so_nguoi'      => $r->so_nguoi,
            'trang_thai'    => $r->trang_thai,
            'created_at'    => $r->created_at,
            'media' => $r->media->map(fn($m)=>[
                'url'=>$m->url, 'type'=>$m->type, 'thumb'=>$m->thumb,
            ])->values(),
            'vattu_chitiet' => $r->vattuChiTiet->map(function($c){
                return [
                    'ten'      => $c->vattu->ten ?? '',
                    'so_luong' => $c->so_luong,
                    'don_vi'   => $c->don_vi ?: ($c->vattu->don_vi ?? ''),
                ];
            })->values(),
        ]);
    }
    public function danhsach(Request $request)
    {
        $q = YeuCau::query()
            ->with(['vattuChiTiet.vattu', 'media'])
            ->orderByDesc('id');

        // === 1. Lọc theo loại (cứu người / nhu yếu phẩm)
        if ($request->filled('loai')) {
            $q->where('loai', $request->loai);
        }

        // === 2. Lọc theo trạng thái
        if ($request->filled('trang_thai')) {
            // cho phép truyền nhiều trạng thái cách nhau dấu phẩy
            $statuses = array_map('trim', explode(',', $request->trang_thai));
            $q->whereIn('trang_thai', $statuses);
        }

        // === 3. Từ khóa tìm kiếm (frontend gửi param "q")
        if ($request->filled('q')) {
            $kw = trim($request->q);
            $q->where(function ($s) use ($kw) {
                if (ctype_digit($kw)) {
                    $s->orWhere('id', (int) $kw);
                }
                $s->orWhere('ten_nguoigui', 'like', "%$kw%")
                    ->orWhere('sdt_nguoigui', 'like', "%$kw%")
                    ->orWhere('noidung', 'like', "%$kw%");
            });
        }

        // === 4. Khoảng thời gian (giờ)
        if ($request->filled('hours')) {
            $q->where('created_at', '>=', now()->subHours((int)$request->hours));
        }

        // === 5. Lọc theo bán kính (km) nếu có center
        if ($request->filled('center_lat') && $request->filled('center_lng') && $request->filled('radius_km')) {
            $lat = (float) $request->center_lat;
            $lng = (float) $request->center_lng;
            $radius = (float) $request->radius_km;

            $q->selectRaw(
                "yeu_cau.*, (6371 * acos(cos(radians(?)) * cos(radians(lat)) * cos(radians(lng) - radians(?)) + sin(radians(?)) * sin(radians(lat)))) as khoang_cach",
                [$lat, $lng, $lat]
            )->having('khoang_cach', '<=', $radius);
        }

        // === 6. Lấy dữ liệu
        $list = $q->limit(500)->get()->map(function ($item) {
            return [
                'id'           => $item->id,
                'loai'         => $item->loai,
                'trang_thai'   => $item->trang_thai,
                'lat'          => $item->lat,
                'lng'          => $item->lng,
                'ten_nguoigui' => $item->ten_nguoigui,
                'sdt_nguoigui' => $item->sdt_nguoigui,
                'noidung'      => $item->noidung,
                'so_nguoi'     => $item->so_nguoi,
                'vattu'        => $item->vattuChiTiet?->map(fn($v) => [
                        'ten'      => $v->vattu?->ten,
                        'so_luong' => $v->so_luong,
                        'don_vi'   => $v->vattu?->don_vi,
                    ])->values() ?? [],
                'media' => $item->media?->map(fn($m) => [
                        'id'   => $m->id,
                        'url'  => url($m->url), // chuyển đường dẫn tương đối -> tuyệt đối
                        'type' => str_contains($m->mime ?? '', 'video') ? 'video' : 'image',
                    ])->values() ?? [],
                // Chuyển về ISO-8601 có timezone VN để FE hiển thị chính xác "mấy phút trước"
                'created_at' => optional($item->created_at)
                    ->setTimezone('Asia/Ho_Chi_Minh')
                    ->toIso8601String(),
            ];
        });

        return response()->json([
            'status' => true,
            'count'  => $list->count(),
            'data'   => $list,
        ]);
    }



    public function tao(Request $request)
    {
        $data = $request->validate([
            'loai'          => ['required', Rule::in(['cuu_nguoi','nhu_yeu_pham'])],
            'ten_nguoigui'  => ['required','string','max:255'],
            'sdt_nguoigui'  => ['required','string','max:30'],
            'noidung'       => ['required','string'],
            'lat'           => ['required','numeric'],
            'lng'           => ['required','numeric'],
            'so_nguoi'      => ['nullable','integer','min:1'],
            'vattu_chitiet' => ['nullable','string'],     // JSON: [{vattu_id, so_luong}]
            'files.*'       => ['nullable','file','max:15360'],
        ]);

        // chặn số điện thoại đã có yêu cầu "tiep_nhan"
        $dup = YeuCau::where('sdt_nguoigui', $data['sdt_nguoigui'])
            ->where('trang_thai','tiep_nhan')
            ->latest('id')->first();
        if ($dup) {
            return response()->json([
                'status' => false,
                'message' => 'Số điện thoại này đã có yêu cầu đang tiếp nhận.',
                'existing_id' => $dup->id,
            ], 409);
        }

        return \DB::transaction(function () use ($request, $data) {
            $data['trang_thai'] = 'tiep_nhan';
            if (empty($data['so_nguoi'])) $data['so_nguoi'] = 1;

            $yc = YeuCau::create($data);

            // LƯU VẬT TƯ CHI TIẾT
            $vtArr = json_decode($request->input('vattu_chitiet', '[]'), true) ?: [];
            foreach ($vtArr as $row) {
                if (empty($row['vattu_id']) || empty($row['so_luong'])) continue;

                $v = VatTu::find((int)$row['vattu_id']);
                if (!$v) continue;

                // tạo qua quan hệ -> Eloquent tự gán yeu_cau_id = $yc->id
                $yc->vattuChiTiet()->create([
                    'vattu_id'  => (int)$v->id,
                    'so_luong'  => (float)$row['so_luong'],
                    'ten_vattu' => $v->ten,           // ✅ gán tên
                    'donvi'     => $v->don_vi ?? '',  // ✅ gán đơn vị
                ]);
            }

            // LƯU FILE ĐÍNH KÈM (đường dẫn tương đối)
            if ($request->hasFile('files')) {
                foreach ($request->file('files') as $file) {
                    $path = $file->store('yeucau', 'public'); // storage/app/public/yeucau/...
                    TepDinhKem::create([
                        'doi_tuong'    => 'yeu_cau',
                        'doi_tuong_id' => $yc->id,
                        'duong_dan'    => 'storage/' . $path,
                        'mime'         => $file->getClientMimeType(),
                        'kich_thuoc'   => $file->getSize(),
                    ]);
                }
            }

            return response()->json(['status'=>true, 'id'=>$yc->id], 201);
        });
    }

    // === Trang chi tiết yêu cầu ===
    public function chitiet($id)
    {
        $yc = YeuCau::with(['vattuChiTiet.vattu','media'])->findOrFail($id);

        return response()->json([
            'id'           => $yc->id,
            'loai'         => $yc->loai,
            'trang_thai'   => $yc->trang_thai,
            'lat'          => $yc->lat,
            'lng'          => $yc->lng,
            'ten_nguoigui' => $yc->ten_nguoigui,
            'sdt_nguoigui' => $yc->sdt_nguoigui,
            'noidung'      => $yc->noidung,
            'so_nguoi'     => $yc->so_nguoi,
            'vattu' => $yc->vattuChiTiet->map(function($r){
                return [
                    'ten'      => $r->ten_vattu ?? $r->vattu?->ten,
                    'so_luong' => $r->so_luong,
                    'don_vi'   => $r->donvi ?? $r->vattu?->don_vi,
                ];
            })->values(),
            'media'        => $yc->media->map(fn($m)=>[
                'id'=>$m->id,
                'url'=>$m->url,
                'type'=> str_contains($m->mime,'video') ? 'video' : 'image'
            ])->values(),
            'created_at'   => optional($yc->created_at)->format('Y-m-d H:i:s'),
        ]);
    }

    public function sua($id, Request $r) {
        $upd = $r->only(['tieu_de','noidung','lat','lng','so_nguoi']);
        if (!$upd) return ['ok'=>true];
        $upd['updated_at'] = now();
        DB::table('yeu_cau')->where('id',$id)->update($upd);

        DB::table('yeu_cau_nhatky')->insert([
            'yeu_cau_id'=>$id,'thuc_hien_boi'=>auth()->id(),
            'hanh_dong'=>'sua','tao_luc'=>now()
        ]);
        return ['ok'=>true];
    }

    public function giao($id, Request $r) {
        $r->validate(['user_id'=>'required|integer']);
        $curr = DB::table('yeu_cau')->where('id',$id)->first();
        DB::table('yeu_cau')->where('id',$id)->update(['duoc_giao_cho'=>$r->user_id,'updated_at'=>now()]);
        DB::table('yeu_cau_nhatky')->insert([
            'yeu_cau_id'=>$id,'thuc_hien_boi'=>auth()->id(),'hanh_dong'=>'gan_nguoi',
            'tu_nguoi'=>$curr->duoc_giao_cho,'den_nguoi'=>$r->user_id,'tao_luc'=>now()
        ]);
        return ['ok'=>true];
    }

    public function doiTrangThai($id, Request $r) {
        $r->validate(['trang_thai'=>'required|in:tiep_nhan,dang_xuly,hoan_thanh,huy','ghichu'=>'nullable|string']);
        $curr = DB::table('yeu_cau')->where('id',$id)->first();
        DB::table('yeu_cau')->where('id',$id)->update(['trang_thai'=>$r->trang_thai,'updated_at'=>now()]);
        DB::table('yeu_cau_nhatky')->insert([
            'yeu_cau_id'=>$id,'thuc_hien_boi'=>auth()->id(),'hanh_dong'=>'doi_trang_thai',
            'tu_trangthai'=>$curr->trang_thai,'den_trangthai'=>$r->trang_thai,'ghichu'=>$r->ghichu,'tao_luc'=>now()
        ]);
        return ['ok'=>true];
    }

    public function nhatKy($id) {
        return DB::table('yeu_cau_nhatky')->where('yeu_cau_id',$id)->orderBy('id','desc')->get();
    }
}
