<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\YeuCauController;
use App\Http\Controllers\KhoController;
use App\Http\Controllers\VietMapController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post('/dangnhap', [AuthController::class,'dangNhap']);

// Yêu cầu (public xem + tạo)
Route::get('/yeucau', [YeuCauController::class,'danhsach']);
Route::get('/xemyeucau/{id}', [YeuCauController::class,'chitiet']);
Route::post('/yeucau', [YeuCauController::class,'tao']); // multipart: tep[]

Route::get('/vattu', [KhoController::class,'dsVatTu']);
Route::middleware('auth:sanctum')->group(function () {

    // Yêu cầu (quản trị)
    Route::get('/admin/yeucau', [\App\Http\Controllers\YeuCauController::class, 'indexAdmin']);
    Route::patch('/admin/yeucau/{id}', [YeuCauController::class,'sua']);
    Route::post('/admin/yeucau/{id}/giao', [YeuCauController::class,'giao']);
    Route::post('/admin/yeucau/{id}/trangthai', [YeuCauController::class,'doiTrangThai']);
    Route::get('/admin/yeucau/{id}/nhatky', [YeuCauController::class,'nhatKy']);

    // Kho nhiều chi nhánh
    Route::get('/kho', [KhoController::class,'dsKho']);             // tổng tồn từng kho
    Route::post('/kho', [KhoController::class,'taoKho']);
    Route::get('/kho/{khoId}/ton', [KhoController::class,'tonKho']); // tồn chi tiết
    Route::post('/kho/giaodich', [KhoController::class,'giaoDich']); // nhập/xuất
    Route::post('/kho/chuyen', [KhoController::class,'chuyenKho']);  // chuyển giữa 2 kho

    // Danh mục vật tư
    //Route::post('/admin/vattu', [KhoController::class,'taoVatTu']);


    Route::get('/users', [UserController::class,'index']);

    // CỤM
    Route::get('/cum',        [\App\Http\Controllers\CumController::class, 'index']);
    Route::post('/cum',       [\App\Http\Controllers\CumController::class, 'store']);
    Route::get('/cum/{id}',   [\App\Http\Controllers\CumController::class, 'show']);
    Route::put('/cum/{id}',   [\App\Http\Controllers\CumController::class, 'update']);
    Route::delete('/cum/{id}',[\App\Http\Controllers\CumController::class, 'destroy']);

    // KHO
    Route::get('/kho',        [\App\Http\Controllers\KhoController::class, 'index']);
    Route::get('/kho/tons',   [\App\Http\Controllers\KhoController::class, 'tons']);
    Route::get('/kho/history',[\App\Http\Controllers\KhoController::class, 'history']);
    Route::post('/kho/nhap',  [\App\Http\Controllers\KhoController::class, 'nhap']);
    Route::post('/kho/xuat',  [\App\Http\Controllers\KhoController::class, 'xuat']);
    Route::post('/kho/chuyen',[\App\Http\Controllers\KhoController::class, 'chuyen']);

    // YÊU CẦU + PHÂN CÔNG
    Route::get('/yeucau',         [\App\Http\Controllers\YeuCauController::class, 'index']);
    Route::get('/yeucau/{id}',    [\App\Http\Controllers\YeuCauController::class, 'show']);
    Route::put('/yeucau/{id}',    [\App\Http\Controllers\YeuCauController::class, 'update']);
    Route::post('/yeucau/{id}/assign', [\App\Http\Controllers\PhanCongController::class, 'assign']);

    // VẬT TƯ
    Route::get('/admin/vattu',          [\App\Http\Controllers\VatTuController::class, 'index']);
    Route::post('/admin/vattu',         [\App\Http\Controllers\VatTuController::class, 'store']);
    Route::get('/admin/vattu/{id}',     [\App\Http\Controllers\VatTuController::class, 'show']);
    Route::put('/admin/vattu/{id}',     [\App\Http\Controllers\VatTuController::class, 'update']);
    Route::delete('/admin/vattu/{id}',  [\App\Http\Controllers\VatTuController::class, 'destroy']);

    // THỐNG KÊ
    Route::get('/thongke', [\App\Http\Controllers\ThongKeController::class, 'index']);

    // USERS
    Route::get('/users',        [\App\Http\Controllers\UserController::class, 'index']);
    Route::get('/users/{id}',   [\App\Http\Controllers\UserController::class, 'show']);
    Route::post('/users',       [\App\Http\Controllers\UserController::class, 'store']);   // tạo
    Route::put('/users/{id}',   [\App\Http\Controllers\UserController::class, 'update']);  // cập nhật
    Route::delete('/users/{id}',[\App\Http\Controllers\UserController::class, 'destroy']);

});

// Proxy VietMap (giấu key)
Route::get('/vietmap/geocode', [VietMapController::class,'geocode']);
Route::get('/vietmap/route',   [VietMapController::class,'route']);
