'use client';
import { useEffect, useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
    listKho,
    listVatTu,
    khoTons,
    khoHistory,
    khoNhap,
    khoXuat,
    khoChuyen,
} from '@/lib/api';

type TabKey = 'ton' | 'nhap' | 'xuat' | 'chuyen' | 'ls';

type Kho = { id: number; ten: string; cum?: { id: number; ten: string } | null };
type VatTu = { id: number; ten: string; don_vi?: string | null };
type Ton = { id: number; kho_id: number; vat_tu?: VatTu; so_luong: number };
type LichSuItem = {
    id: number;
    loai: 'nhap' | 'xuat' | 'chuyen';
    kho_from?: Kho | null;
    kho_to?: Kho | null;
    chi_tiet?: Array<{ id: number; vat_tu?: VatTu; so_luong: number; don_vi?: string | null }>;
    nguoi_tao?: { id: number; name: string };
    created_at?: string;
};

type NXRow = { vat_tu_id: string; so_luong: string; don_vi: string };

export default function KhoPage() {
    const [tab, setTab] = useState<TabKey>('ton');

    // master data
    const [khos, setKhos] = useState<Kho[]>([]);
    const [khoId, setKhoId] = useState<string>(''); // kho đang chọn
    const [vattu, setVattu] = useState<VatTu[]>([]);

    // tồn
    const [tons, setTons] = useState<Ton[]>([]);
    const [tonsLoading, setTonsLoading] = useState(false);

    // lịch sử
    const [hist, setHist] = useState<LichSuItem[]>([]);
    const [histLoading, setHistLoading] = useState(false);

    // nhập / xuất / chuyển
    const [items, setItems] = useState<NXRow[]>([{ vat_tu_id: '', so_luong: '', don_vi: '' }]);
    const [submitLoading, setSubmitLoading] = useState(false);

    // chuyển kho: chọn kho đến
    const [khoToId, setKhoToId] = useState<string>('');

    // tải danh mục kho & vật tư
    useEffect(() => {
        (async () => {
            const kh = await listKho({ per_page: 999 });
            setKhos(kh.data ?? kh);

            const vt = await listVatTu({ per_page: 9999 });
            setVattu(vt.data ?? vt);
        })();
    }, []);

    // tải tồn
    useEffect(() => {
        if (tab !== 'ton') return;
        (async () => {
            setTonsLoading(true);
            try {
                const d = await khoTons({ kho_id: khoId || undefined, per_page: 9999 });
                setTons(d.data ?? d);
            } finally {
                setTonsLoading(false);
            }
        })();
    }, [tab, khoId]);

    // tải lịch sử
    useEffect(() => {
        if (tab !== 'ls') return;
        (async () => {
            setHistLoading(true);
            try {
                const d = await khoHistory({ kho_id: khoId || undefined, per_page: 100 });
                setHist(d.data ?? d);
            } finally {
                setHistLoading(false);
            }
        })();
    }, [tab, khoId]);

    // helper
    const currentKho = useMemo(() => khos.find(k => String(k.id) === khoId), [khos, khoId]);
    const khoToList = useMemo(
        () => khos.filter(k => String(k.id) !== khoId),
        [khos, khoId]
    );

    const addRow = () =>
        setItems(arr => [...arr, { vat_tu_id: '', so_luong: '', don_vi: '' }]);

    const updateRow = (index: number, patch: Partial<NXRow>) =>
        setItems(arr => arr.map((r, i) => (i === index ? { ...r, ...patch } : r)));

    const removeRow = (index: number) =>
        setItems(arr => arr.filter((_, i) => i !== index));

    // validate form NX
    const validItems = useMemo(
        () =>
            items
                .map(r => ({
                    vat_tu_id: Number(r.vat_tu_id),
                    so_luong: Number(r.so_luong),
                    don_vi: r.don_vi?.trim() || undefined,
                }))
                .filter(r => r.vat_tu_id > 0 && r.so_luong > 0),
        [items]
    );

    const canSubmitNhap = tab === 'nhap' && Number(khoId) > 0 && validItems.length > 0;
    const canSubmitXuat = tab === 'xuat' && Number(khoId) > 0 && validItems.length > 0;
    const canSubmitChuyen =
        tab === 'chuyen' &&
        Number(khoId) > 0 &&
        Number(khoToId) > 0 &&
        khoToId !== khoId &&
        validItems.length > 0;

    const resetForm = () => {
        setItems([{ vat_tu_id: '', so_luong: '', don_vi: '' }]);
        setKhoToId('');
    };

    const submitNX = async () => {
        try {
            setSubmitLoading(true);
            if (tab === 'nhap') {
                await khoNhap({ kho_to_id: Number(khoId), items: validItems });
                alert('Nhập kho thành công');
            } else if (tab === 'xuat') {
                await khoXuat({ kho_from_id: Number(khoId), items: validItems });
                alert('Xuất kho thành công');
            } else if (tab === 'chuyen') {
                await khoChuyen({
                    kho_from_id: Number(khoId),
                    kho_to_id: Number(khoToId),
                    items: validItems,
                });
                alert('Chuyển kho thành công');
            }
            resetForm();
            // refresh tồn/lịch sử nếu đang ở tab tương ứng
            if (tab === 'ton') {
                const d = await khoTons({ kho_id: khoId || undefined, per_page: 9999 });
                setTons(d.data ?? d);
            }
            if (tab === 'ls') {
                const d = await khoHistory({ kho_id: khoId || undefined, per_page: 100 });
                setHist(d.data ?? d);
            }
        } catch (e: any) {
            alert(e?.response?.data?.message || e?.message || 'Lỗi thao tác kho');
        } finally {
            setSubmitLoading(false);
        }
    };

    const TopBar = (
        <div className="flex items-center gap-2">
            {/* Chọn kho hiện hành */}
            <select
                className="border rounded h-10 px-2"
                value={khoId}
                onChange={e => setKhoId(e.target.value)}
            >
                <option value="">-- Chọn kho --</option>
                {khos.map(k => (
                    <option key={k.id} value={k.id}>
                        {k.ten} {k.cum ? `(Cụm ${k.cum.ten})` : ''}
                    </option>
                ))}
            </select>

            <div className="ml-auto flex gap-2">
                {(['ton', 'nhap', 'xuat', 'chuyen', 'ls'] as const).map(t => (
                    <Button
                        key={t}
                        variant={tab === t ? 'default' : 'outline'}
                        onClick={() => setTab(t)}
                    >
                        {t === 'ton'
                            ? 'TỒN'
                            : t === 'nhap'
                                ? 'NHẬP'
                                : t === 'xuat'
                                    ? 'XUẤT'
                                    : t === 'chuyen'
                                        ? 'CHUYỂN'
                                        : 'LỊCH SỬ'}
                    </Button>
                ))}
            </div>
        </div>
    );

    const RowEditor = (r: NXRow, i: number) => {
        const vt = vattu.find(v => String(v.id) === r.vat_tu_id);
        return (
            <div key={i} className="grid md:grid-cols-12 gap-2 items-center">
                <div className="md:col-span-6">
                    <select
                        className="border rounded h-10 px-2 w-full"
                        value={r.vat_tu_id}
                        onChange={e => updateRow(i, { vat_tu_id: e.target.value })}
                    >
                        <option value="">-- Vật tư --</option>
                        {vattu.map(v => (
                            <option key={v.id} value={v.id}>
                                {v.ten}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="md:col-span-3">
                    <Input
                        placeholder="Số lượng"
                        value={r.so_luong}
                        onChange={e => updateRow(i, { so_luong: e.target.value })}
                    />
                </div>
                <div className="md:col-span-2">
                    <Input
                        placeholder={`Đơn vị${vt?.don_vi ? ` (${vt.don_vi})` : ''}`}
                        value={r.don_vi}
                        onChange={e => updateRow(i, { don_vi: e.target.value })}
                    />
                </div>
                <div className="md:col-span-1 flex justify-end">
                    <Button
                        type="button"
                        variant="outline"
                        onClick={() => removeRow(i)}
                        disabled={items.length === 1}
                    >
                        Xóa
                    </Button>
                </div>
            </div>
        );
    };

    return (
        <div className="p-4 space-y-4">
            {TopBar}

            {/* TỒN */}
            {tab === 'ton' && (
                <div className="grid gap-2">
                    {tonsLoading ? (
                        <div className="text-sm text-muted-foreground">Đang tải tồn kho…</div>
                    ) : tons.length === 0 ? (
                        <div className="text-sm text-muted-foreground">Chưa có dữ liệu tồn.</div>
                    ) : (
                        tons.map(t => (
                            <div
                                key={t.id}
                                className="border rounded p-3 flex justify-between items-center"
                            >
                                <div className="text-sm">
                                    <div className="font-medium">{t.vat_tu?.ten}</div>
                                    {t.vat_tu?.don_vi ? (
                                        <div className="text-muted-foreground">
                                            Đơn vị: {t.vat_tu.don_vi}
                                        </div>
                                    ) : null}
                                </div>
                                <div className="text-base font-semibold">
                                    {t.so_luong} {t.vat_tu?.don_vi || ''}
                                </div>
                            </div>
                        ))
                    )}
                </div>
            )}

            {/* NHẬP / XUẤT / CHUYỂN */}
            {['nhap', 'xuat', 'chuyen'].includes(tab) && (
                <div className="space-y-4">
                    {/* Gợi ý kho đang thao tác */}
                    <div className="text-sm">
                        <b>Kho hiện hành:</b>{' '}
                        {currentKho ? `${currentKho.ten}${currentKho.cum ? ` (Cụm ${currentKho.cum.ten})` : ''}` : '—'}
                    </div>

                    {/* Chọn kho đến khi CHUYỂN */}
                    {tab === 'chuyen' && (
                        <div className="grid md:grid-cols-12 gap-2">
                            <div className="md:col-span-6">
                                <label className="text-sm font-medium block mb-1">
                                    Kho đến
                                </label>
                                <select
                                    className="border rounded h-10 px-2 w-full"
                                    value={khoToId}
                                    onChange={e => setKhoToId(e.target.value)}
                                >
                                    <option value="">-- Chọn kho đến --</option>
                                    {khoToList.map(k => (
                                        <option key={k.id} value={k.id}>
                                            {k.ten} {k.cum ? `(Cụm ${k.cum.ten})` : ''}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    )}

                    {/* Danh sách dòng hàng */}
                    <div className="space-y-2">
                        {items.map((r, i) => RowEditor(r, i))}
                        <Button
                            type="button"
                            variant="outline"
                            onClick={addRow}
                            className="mt-1"
                        >
                            + Thêm dòng
                        </Button>
                    </div>

                    <div className="flex gap-2">
                        <Button
                            onClick={submitNX}
                            disabled={
                                submitLoading ||
                                (tab === 'nhap' && !canSubmitNhap) ||
                                (tab === 'xuat' && !canSubmitXuat) ||
                                (tab === 'chuyen' && !canSubmitChuyen)
                            }
                        >
                            {submitLoading
                                ? 'Đang xử lý...'
                                : tab === 'nhap'
                                    ? 'Xác nhận NHẬP'
                                    : tab === 'xuat'
                                        ? 'Xác nhận XUẤT'
                                        : 'Xác nhận CHUYỂN'}
                        </Button>
                        <Button variant="outline" onClick={resetForm}>
                            Xóa trắng
                        </Button>
                    </div>
                </div>
            )}

            {/* LỊCH SỬ */}
            {tab === 'ls' && (
                <div className="grid gap-2">
                    {histLoading ? (
                        <div className="text-sm text-muted-foreground">Đang tải lịch sử…</div>
                    ) : hist.length === 0 ? (
                        <div className="text-sm text-muted-foreground">Chưa có lịch sử.</div>
                    ) : (
                        hist.map(h => (
                            <div key={h.id} className="border rounded p-3">
                                <div className="font-medium">
                                    Phiếu #{h.id} – {h.loai.toUpperCase()}
                                </div>
                                <div className="text-sm">
                                    {h.loai === 'nhap' && (
                                        <div>
                                            <span className="text-muted-foreground">Kho đến: </span>
                                            <b>{h.kho_to?.ten || '—'}</b>
                                        </div>
                                    )}
                                    {h.loai === 'xuat' && (
                                        <div>
                                            <span className="text-muted-foreground">Kho đi: </span>
                                            <b>{h.kho_from?.ten || '—'}</b>
                                        </div>
                                    )}
                                    {h.loai === 'chuyen' && (
                                        <div>
                                            <span className="text-muted-foreground">Từ: </span>
                                            <b>{h.kho_from?.ten || '—'}</b> <span className="mx-1">→</span>{' '}
                                            <span className="text-muted-foreground">Đến: </span>
                                            <b>{h.kho_to?.ten || '—'}</b>
                                        </div>
                                    )}
                                    <div className="text-muted-foreground">
                                        Người tạo: {h.nguoi_tao?.name || '—'} {h.created_at ? `· ${h.created_at}` : ''}
                                    </div>
                                </div>
                                <ul className="list-disc pl-5 text-sm mt-2">
                                    {h.chi_tiet?.map(c => (
                                        <li key={c.id}>
                                            {c.vat_tu?.ten}: <b>{c.so_luong}</b> {c.don_vi || c.vat_tu?.don_vi || ''}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ))
                    )}
                </div>
            )}
        </div>
    );
}
