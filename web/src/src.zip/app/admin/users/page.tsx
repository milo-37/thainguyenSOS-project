'use client';
import { useEffect, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { listUsers, createUser, updateUser, deleteUser } from '@/lib/api';

type User = { id:number; name:string; email:string; phone?:string|null; role:'admin'|'leader'|'member' };

export default function UsersPage(){
    const [items,setItems] = useState<User[]>([]);
    const [q,setQ] = useState('');
    const [page,setPage] = useState(1);
    const [total,setTotal] = useState(0);
    const [perPage,setPerPage] = useState(20);

    const [editing,setEditing] = useState<User|null>(null);
    const [form,setForm] = useState<any>({ name:'', email:'', phone:'', role:'member', password:'' });

    const load = async()=>{
        const d = await listUsers({ q, page, per_page: perPage });
        setItems(d.data ?? d.items ?? d);
        setTotal(d.total ?? (d.data ? d.data.length : 0));
    };

    useEffect(()=>{ load(); },[q,page]);

    const onEdit = (u:User)=>{
        setEditing(u);
        setForm({ name:u.name, email:u.email, phone:u.phone||'', role:u.role, password:'' });
    };

    const onNew = ()=>{
        setEditing(null);
        setForm({ name:'', email:'', phone:'', role:'member', password:'' });
    };

    const onSave = async()=>{
        if (editing) await updateUser(editing.id, { ...form, password: form.password || undefined });
        else         await createUser(form);
        onNew();
        load();
    };

    return (
        <div className="p-4 space-y-4">
            <div className="flex items-center gap-2">
                <Input placeholder="Tìm theo tên, email, SĐT..." value={q} onChange={e=>setQ(e.target.value)} className="max-w-sm" />
                <div className="ml-auto">
                    <Button onClick={onNew}>+ Người dùng</Button>
                </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
                {/* Form */}
                <div className="border rounded-xl p-4 space-y-2">
                    <div className="font-semibold">{editing ? 'Sửa người dùng' : 'Thêm người dùng'}</div>
                    <Input placeholder="Họ tên" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
                    <Input placeholder="Email"  value={form.email} onChange={e=>setForm({...form,email:e.target.value})} />
                    <Input placeholder="SĐT"    value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} />
                    <select className="border rounded h-10 px-2 w-full" value={form.role} onChange={e=>setForm({...form,role:e.target.value})}>
                        <option value="member">Thành viên</option>
                        <option value="leader">Chỉ huy cụm</option>
                        <option value="admin">Quản trị</option>
                    </select>
                    <Input type="password" placeholder={editing ? "Đổi mật khẩu (bỏ trống nếu giữ nguyên)" : "Mật khẩu"}
                           value={form.password} onChange={e=>setForm({...form,password:e.target.value})} />
                    <div className="flex gap-2">
                        <Button onClick={onSave}>Lưu</Button>
                        {editing && <Button variant="outline" onClick={onNew}>Huỷ</Button>}
                    </div>
                </div>

                {/* Danh sách */}
                <div className="md:col-span-2 grid gap-2">
                    {items.map(u=>(
                        <div key={u.id} className="border rounded p-3 flex items-center justify-between">
                            <div>
                                <div className="font-medium">{u.name} <span className="text-xs px-2 py-0.5 rounded bg-gray-100 ml-2">{u.role}</span></div>
                                <div className="text-sm text-muted-foreground">{u.email}{u.phone ? ` · ${u.phone}`:''}</div>
                            </div>
                            <div className="flex gap-2">
                                <Button size="sm" variant="secondary" onClick={()=>onEdit(u)}>Sửa</Button>
                                <Button size="sm" variant="destructive" onClick={async()=>{ if(confirm('Xoá người dùng này?')){ await deleteUser(u.id); load(); }}}>Xoá</Button>
                            </div>
                        </div>
                    ))}
                    {/* phân trang đơn giản */}
                    <div className="flex justify-center gap-2 mt-2">
                        <Button variant="outline" onClick={()=>setPage(p=>Math.max(1,p-1))}>Trước</Button>
                        <Button variant="outline" onClick={()=>setPage(p=>p+1)}>Sau</Button>
                    </div>
                </div>
            </div>
        </div>
    );
}
