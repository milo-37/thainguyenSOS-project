// src/lib/api.ts
export const API = "/api"; // dùng proxy Next (next.config.ts -> rewrites)

export function authHeader() {
    const token =
        typeof window !== "undefined" ? localStorage.getItem("token") : null;
    return token ? { Authorization: `Bearer ${token}` } : {};
}

// Gọi API JSON tiện dụng
export async function api(path: string, init?: RequestInit) {
    const url = `${API}${path.startsWith("/") ? "" : "/"}${path}`;
    const res = await fetch(url, {
        ...init,
        headers: {
            "Content-Type": "application/json",
            ...(init?.headers || {}),
            ...authHeader(),
            Accept: "application/json",
            "X-Requested-With": "XMLHttpRequest",
        },
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

// Multipart form (upload)
export async function apiForm(path: string, fd: FormData) {
    const url = `${API}${path.startsWith("/") ? "" : "/"}${path}`;
    const res = await fetch(url, {
        method: "POST",
        body: fd,
        headers: {
            ...authHeader(),
            Accept: "application/json",
            "X-Requested-With": "XMLHttpRequest",
        },
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

// ---------------------------------------------------------
// CỤM
// ---------------------------------------------------------
export async function listClusters(q?: string, page = 1) {
    return api(`/cum?q=${encodeURIComponent(q || "")}&page=${page}`);
}
export async function getCluster(id: number) {
    return api(`/cum/${id}`);
}
export async function createCluster(payload: any) {
    return api(`/cum`, { method: "POST", body: JSON.stringify(payload) });
}
export async function updateCluster(id: number, payload: any) {
    return api(`/cum/${id}`, { method: "PUT", body: JSON.stringify(payload) });
}
export async function deleteCluster(id: number) {
    return api(`/cum/${id}`, { method: "DELETE" });
}

// ---------------------------------------------------------
// YÊU CẦU
// ---------------------------------------------------------
export async function listYeuCau(params: any = {}) {
    const usp = new URLSearchParams(params).toString();
    return api(`/yeucau${usp ? "?" + usp : ""}`);
}

export async function getYeuCau(id: number) {
    return api(`/yeucau/${id}`);
}

export async function updateYeuCau(id: number, body: any) {
    return api(`/yeucau/${id}`, {
        method: "PUT",
        body: JSON.stringify(body),
    });
}

export async function assignYeuCau(
    id: number,
    body: { cum_id?: number; user_id?: number }
) {
    return api(`/yeucau/${id}/assign`, {
        method: "POST",
        body: JSON.stringify(body),
    });
}

// ---------------------------------------------------------
// KHO  (giữ block này, xóa các block KHO khác trùng tên)
// ---------------------------------------------------------
export async function listKho(params: any = {}) {
    const usp = new URLSearchParams(params).toString();
    return api(`/kho${usp ? "?" + usp : ""}`);
}

export async function khoTons(params: any = {}) {
    const usp = new URLSearchParams(params).toString();
    return api(`/kho/tons${usp ? "?" + usp : ""}`);
}

export async function khoHistory(params: any = {}) {
    const usp = new URLSearchParams(params).toString();
    return api(`/kho/history${usp ? "?" + usp : ""}`);
}

export async function khoNhap(body: any) {
    return api(`/kho/nhap`, { method: "POST", body: JSON.stringify(body) });
}

export async function khoXuat(body: any) {
    return api(`/kho/xuat`, { method: "POST", body: JSON.stringify(body) });
}

export async function khoChuyen(body: any) {
    return api(`/kho/chuyen`, { method: "POST", body: JSON.stringify(body) });
}
// ---------------------------------------------------------
// THỐNG KÊ
// ---------------------------------------------------------
export async function thongKe(params: any = {}) {
    const usp = new URLSearchParams(params).toString();
    return api(`/thongke${usp ? "?" + usp : ""}`);
}

// ---------------------------------------------------------
// VẬT TƯ
// ---------------------------------------------------------
export async function listVatTu(params: any = {}) {
    const usp = new URLSearchParams(params).toString();
    return api(`/admin/vattu${usp ? "?" + usp : ""}`);
}
export async function createVatTu(body: any) {
    return api(`/admin/vattu`, { method: "POST", body: JSON.stringify(body) });
}
export async function updateVatTu(id: number, body: any) {
    return api(`/admin/vattu/${id}`, { method: "PUT", body: JSON.stringify(body) });
}
export async function deleteVatTu(id: number) {
    return api(`/admin/vattu/${id}`, { method: "DELETE" });
}
export async function listYeuCauAdmin(params: any = {}) {
    const usp = new URLSearchParams(params).toString();
    return api(`/admin/yeucau${usp ? "?" + usp : ""}`);
}
// USERS
export async function listUsers(params: any = {}) {
    const usp = new URLSearchParams(params).toString();
    return api(`/users${usp ? `?${usp}` : ''}`);
}
export async function getUser(id: number) {
    return api(`/users/${id}`);
}
export async function createUser(body: any) {
    return api(`/users`, { method: 'POST', body: JSON.stringify(body) });
}
export async function updateUser(id: number, body: any) {
    return api(`/users/${id}`, { method: 'PUT', body: JSON.stringify(body) });
}
export async function deleteUser(id: number) {
    return api(`/users/${id}`, { method: 'DELETE' });
}
export async function quickUpdateTrangThai(id: number, trang_thai: 'tiep_nhan'|'dang_xu_ly'|'hoan_thanh'|'huy', ghi_chu: string) {
    const token = localStorage.getItem('token') ?? '';
    const url = new URL(`/api/admin/yeucau/${id}/cap-nhat-trang-thai`, process.env.NEXT_PUBLIC_API_URL as string);
    const res = await fetch(url.toString(), {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, Accept: 'application/json', 'Content-Type':'application/json' },
        body: JSON.stringify({ trang_thai, ghi_chu }),
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}

export async function transferAssignment(id: number, payload: {user_id?: number, cum_id?: number, ghi_chu?: string}) {
    const token = localStorage.getItem('token') ?? '';
    const url = new URL(`/api/admin/yeucau/${id}/chuyen-xu-ly`, process.env.NEXT_PUBLIC_API_URL as string);
    const res = await fetch(url.toString(), {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, Accept: 'application/json', 'Content-Type':'application/json' },
        body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
}
// helpers
const buildUrl = (path: string) => {
    const base = (process.env.NEXT_PUBLIC_API_URL || '').replace(/\/+$/, '');
    if (!base) return path.startsWith('/') ? path : `/${path}`;
    return path.startsWith('/') ? `${base}${path}` : `${base}/${path}`;
};
export async function getYeuCauHistory(id: number) {
    const token = localStorage.getItem('token') ?? '';

    const base = (process.env.NEXT_PUBLIC_API_URL || '').replace(/\/+$/, '');
    const buildUrl = (path: string) =>
        path.startsWith('/')
            ? `${base}${path}`
            : `${base}/${path}`;

    // endpoint chính
    const url = buildUrl(`/admin/yeucau/${id}/lich-su`);

    const res = await fetch(url, {
        headers: {
            Authorization: `Bearer ${token}`,
            Accept: 'application/json',
        },
    });

    /*if (!res.ok) {
        // fallback thử /history nếu BE đặt khác tên
        const alt = buildUrl(`/api/admin/yeucau/${id}/history`);
        const res2 = await fetch(alt, {
            headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
        });
        if (!res2.ok)
            throw new Error(
                `Không lấy được lịch sử (HTTP ${res.status} ${res.statusText})`,
            );
        return res2.json();
    }*/
    return res.json();
}
