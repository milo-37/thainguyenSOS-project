import ClusterForm from "../../ClusterForm";
import { getCluster } from "@/lib/api";

async function fetchUsers(token:string) {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/users?limit=1000`, {
        headers: { Authorization: `Bearer ${token}` },
        cache: "no-store",
    });
    const json = await res.json();
    return json.data ?? json;
}

export default async function EditClusterPage({ params }:{ params:{ id:string }}) {
    const token = ""; // lấy token
    const [cluster, allUsers] = await Promise.all([
        getCluster(Number(params.id), token),
        fetchUsers(token)
    ]);

    const init = {
        id: cluster.id,
        name: cluster.name,
        description: cluster.description ?? "",
        member_ids: (cluster.members ?? []).map((m:any)=>m.id),
    };

    return (
        <div className="p-6">
            <h1 className="text-xl font-semibold mb-4">Sửa cụm</h1>
            <ClusterForm token={token} allUsers={allUsers} init={init}/>
        </div>
    );
}
